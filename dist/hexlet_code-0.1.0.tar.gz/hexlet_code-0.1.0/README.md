### Hexlet tests and linter status:
[![Actions Status](https://github.com/MrPerechnev/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/MrPerechnev/python-project-lvl1/actions)

### Maintainability Badge
<a href="https://codeclimate.com/github/MrPerechnev/python-project-lvl1/maintainability"><img src="https://api.codeclimate.com/v1/badges/568b885fbadaa7ecc654/maintainability" /></a>